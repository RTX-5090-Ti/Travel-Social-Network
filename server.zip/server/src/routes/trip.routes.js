import { Router } from "express";
import { requireAuth } from "../middlewares/requireAuth.js";
import { validate } from "../middlewares/validate.js";
import {
  createTripSchema,
  listTripTrashSchema,
  updateTripPinSchema,
  updateTripPrivacySchema,
  updateTripTrashSchema,
} from "../validations/trip.validation.js";
import {
  createTrip,
  getTripDetail,
  listTrashedTrips,
  moveTripToTrash,
  pinTrip,
  restoreTripFromTrash,
  unpinTrip,
  updateTripPrivacy,
} from "../controllers/trip.controller.js";

const router = Router();

router.post("/", requireAuth, validate(createTripSchema), createTrip);

router.patch(
  "/:id/privacy",
  requireAuth,
  validate(updateTripPrivacySchema),
  updateTripPrivacy,
);

router.put("/:id/pin", requireAuth, validate(updateTripPinSchema), pinTrip);

router.delete(
  "/:id/pin",
  requireAuth,
  validate(updateTripPinSchema),
  unpinTrip,
);

router.get("/trash", requireAuth, validate(listTripTrashSchema), listTrashedTrips);

router.patch(
  "/:id/trash",
  requireAuth,
  validate(updateTripTrashSchema),
  moveTripToTrash,
);

router.patch(
  "/:id/restore",
  requireAuth,
  validate(updateTripTrashSchema),
  restoreTripFromTrash,
);

router.get("/:id", requireAuth, getTripDetail);

export default router;
